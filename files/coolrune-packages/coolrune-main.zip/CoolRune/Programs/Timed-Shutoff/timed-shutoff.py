import time
import subprocess

def shutdown_system(command, retries=3):
    """
    Try to shutdown the system with the given command. 
    Retry a few times in case of failure.
    """
    for attempt in range(retries):
        try:
            result = subprocess.run(command, check=True)
            if result.returncode == 0:
                print("Shutdown command executed successfully.")
                return True
        except subprocess.CalledProcessError as e:
            print(f"Attempt {attempt+1} failed: {e}. Retrying...")
            time.sleep(2)  # Wait 2 seconds before retrying
    print("Failed to execute shutdown after several attempts.")
    return False

# Define the command to execute
command = ["xfce4-session-logout", "--halt", "--fast"]

# Prompt the user to enter the desired time in hours and minutes
try:
    hours = int(input("Enter the number of hours: "))
    minutes = int(input("Enter the number of minutes: "))

    # Validate input
    if hours < 0 or minutes < 0 or (hours == 0 and minutes == 0):
        print("Please enter a valid time.")
    else:
        # Calculate the total number of seconds to wait
        total_seconds = hours * 3600 + minutes * 60
        print(f"Shutting down in {hours} hours and {minutes} minutes...")
        
        # Wait for the specified time
        time.sleep(total_seconds)

        # Attempt to execute the shutdown command
        success = shutdown_system(command)

        if not success:
            print("Could not shutdown the system.")
except ValueError:
    print("Invalid input. Please enter numeric values.")
