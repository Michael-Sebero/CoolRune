import numpy as np
import sounddevice as sd
import soundfile as sf
import threading
import queue
import sys

def dominant_frequency(data, samplerate):
    """Return dominant frequency of a chunk of audio data."""
    if len(data) == 0:
        return 0.0
    window = np.hanning(len(data))  # smooth edges
    spectrum = np.fft.rfft(data * window)
    freqs = np.fft.rfftfreq(len(data), 1.0 / samplerate)
    return freqs[np.argmax(np.abs(spectrum))]

def live_frequency_detector(device=None, block_duration=0.1):
    """
    Capture audio in real time and show the dominant frequency.
    
    Parameters:
        device (int or str): Input device ID or name (None = default).
        block_duration (float): Block size in seconds for FFT updates.
    """
    q = queue.Queue()

    def callback(indata, frames, time, status):
        if status:
            print(status, file=sys.stderr)
        q.put(indata[:, 0].copy())  # use first channel

    samplerate = sd.query_devices(device, 'input')['default_samplerate']

    with sd.InputStream(device=device,
                        channels=1,
                        samplerate=int(samplerate),
                        callback=callback,
                        blocksize=int(samplerate * block_duration)):
        print("Listening... Press Ctrl+C to stop.")
        try:
            while True:
                block = q.get()
                freq = dominant_frequency(block, int(samplerate))
                sys.stdout.write(f"\rDominant frequency: {freq:7.2f} Hz")
                sys.stdout.flush()
        except KeyboardInterrupt:
            print("\nStopped.")

def list_devices():
    """List available audio devices."""
    print("\nAvailable audio devices:")
    print(sd.query_devices())

if __name__ == "__main__":
    print("Select mode:\n1. Detect from microphone\n2. Detect from system playback (loopback, if supported)\n3. List devices")
    choice = input("Enter choice (1/2/3): ").strip()

    if choice == "3":
        list_devices()
        sys.exit(0)

    if choice == "1":
        device = None  # default mic
    elif choice == "2":
        print("⚠ Loopback may require selecting the correct device (e.g. WASAPI on Windows).")
        list_devices()
        device = int(input("Enter loopback device ID: ").strip())
    else:
        print("Invalid choice.")
        sys.exit(1)

    live_frequency_detector(device=device)
