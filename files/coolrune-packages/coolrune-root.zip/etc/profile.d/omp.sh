#!/bin/sh
# Set OMP_NUM_THREADS dynamically to the number of physical cores
if command -v lscpu >/dev/null 2>&1; then
  export OMP_NUM_THREADS="$(lscpu -p=CORE | grep -v '^#' | sort -u | wc -l)"
fi
