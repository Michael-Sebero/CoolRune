#!/bin/bash

# Kill programs
pkill xfdesktop || true
pkill xfwm4 || true
pkill wrapper-2.0 || true
pkill tumblerd || true

# Launch programs with mimalloc
LD_PRELOAD=/usr/lib/libmimalloc.so xfdesktop &
sleep 0.1
LD_PRELOAD=/usr/lib/libmimalloc.so xfwm4 &
sleep 0.1
LD_PRELOAD=/usr/lib/libmimalloc.so wrapper-2.0 &
sleep 0.1
LD_PRELOAD=/usr/lib/libmimalloc.so tumblerd &
sleep 0.1
LD_PRELOAD=/usr/lib/libmimalloc.so pipewire &
sleep 0.1
LD_PRELOAD=/usr/lib/libmimalloc.so pipewire-pulse &
sleep 0.1
LD_PRELOAD=/usr/lib/libmimalloc.so wireplumber &
sleep 0.1
LD_PRELOAD=/usr/lib/libmimalloc.so redshift -l geoclue2 -t 6500:5000 -b 1.0:1.0 -m randr -v &
sleep 0.1
LD_PRELOAD=/usr/lib/libmimalloc.so xfce-superkey &
sleep 0.1
LD_PRELOAD=/usr/lib/libmimalloc.so gnome-keyring-daemon

# Disable screensaver
xset -dpms s off s 0 0 || true
