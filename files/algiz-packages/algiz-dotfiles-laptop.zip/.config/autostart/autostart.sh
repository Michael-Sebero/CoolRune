#!/bin/bash

# Launch programs under mimalloc
MIMALLOC_LIB=/usr/lib/libmimalloc.so
export LD_PRELOAD="$MIMALLOC_LIB"

# Kill programs
for p in xfdesktop pipewire pipewire-pulse wireplumber redshift xfce-superkey gnome-keyring-daemon Thunar; do
    pkill -9 -u "$USER" "$p" || true
done

# Launch programs
(
    xfdesktop &
    pipewire &
    pipewire-pulse &
    (sleep 0.05; wireplumber &) 
    redshift -l geoclue2 -t 6500:5000 -b 1.0:1.0 -m randr -v &
    xfce-superkey &
    gnome-keyring-daemon &
    Thunar --daemon &
)
