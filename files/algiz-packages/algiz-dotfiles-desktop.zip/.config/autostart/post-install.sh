#!/bin/bash

pw-play algiz/login-sound/login.wav || true

flatpak update -y || true

pip3 install pydub imagehash pyzipper tinytag eyed3 futures sounddevice python-docx chardet --break-system-packages || true

rm /home/$USER/.config/autostart/post-install.desktop || true
