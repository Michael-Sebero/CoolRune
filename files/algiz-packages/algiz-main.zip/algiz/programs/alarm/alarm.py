import time
from pydub import AudioSegment
from pydub.playback import play
import sys

# Prompt the user to enter the desired time in hours, minutes, and seconds
hours = int(input("Enter the number of hours: "))
minutes = int(input("Enter the number of minutes: "))
seconds = int(input("Enter the number of seconds: "))

# Calculate the total number of seconds to wait
total_seconds = hours * 3600 + minutes * 60 + seconds

print(f"The alarm will go off in {hours} hours, {minutes} minutes, and {seconds} seconds...")
time.sleep(total_seconds)

# Play a sound using pydub
song = AudioSegment.from_mp3("/algiz/system-sounds/alarm-sound/alarm.mp3")
play(song)

sys.exit()
