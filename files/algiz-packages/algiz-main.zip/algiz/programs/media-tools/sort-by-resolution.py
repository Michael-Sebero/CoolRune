import os
import shutil
import subprocess
from PIL import Image

# Adjust this to control grouping granularity
RESOLUTION_BUCKET_SIZE = 200  # e.g. 1920x1080 → 2000x1200

def get_resolution(filename):
    if is_image(filename):
        return get_resolution_image(filename)
    elif is_video(filename):
        return get_resolution_video(filename)
    else:
        return None

def is_image(filename):
    image_extensions = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.tiff']
    _, file_ext = os.path.splitext(filename.lower())
    return file_ext in image_extensions

def is_video(filename):
    video_extensions = ['.mp4', '.avi', '.mkv', '.mov', '.wmv', '.flv', '.webm']
    _, file_ext = os.path.splitext(filename.lower())
    return file_ext in video_extensions

def get_resolution_image(filename):
    try:
        with Image.open(filename) as img:
            return (img.width, img.height)
    except Exception as e:
        print(f"Failed to get image resolution for {filename}: {e}")
        return None

def get_resolution_video(filename):
    try:
        result = subprocess.run([
            "ffprobe", "-v", "error", "-select_streams", "v:0",
            "-show_entries", "stream=width,height", "-of", "csv=p=0:s=x", filename
        ], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        output = result.stdout.strip()
        if "x" in output:
            width, height = map(int, output.split("x"))
            return (width, height)
        return None
    except Exception as e:
        print(f"Failed to get video resolution for {filename}: {e}")
        return None

def bucket_resolution(width, height, bucket_size):
    bucketed_width = ((width + bucket_size - 1) // bucket_size) * bucket_size
    bucketed_height = ((height + bucket_size - 1) // bucket_size) * bucket_size
    return f"{bucketed_width}x{bucketed_height}"

def organize_files(directory):
    resolution_folders = {}
    for filename in os.listdir(directory):
        file_path = os.path.join(directory, filename)
        if os.path.isfile(file_path):
            res = get_resolution(file_path)
            if res:
                width, height = res
                rounded_res = bucket_resolution(width, height, RESOLUTION_BUCKET_SIZE)

                if rounded_res not in resolution_folders:
                    folder_path = os.path.join(directory, rounded_res)
                    os.makedirs(folder_path, exist_ok=True)
                    resolution_folders[rounded_res] = folder_path

                try:
                    shutil.move(file_path, os.path.join(resolution_folders[rounded_res], filename))
                    print(f"Moved {filename} to {rounded_res}")
                except Exception as e:
                    print(f"Failed to move {filename}: {e}")

if __name__ == "__main__":
    input_directory = input("Enter the directory: ").strip()
    if os.path.exists(input_directory) and os.path.isdir(input_directory):
        organize_files(input_directory)
        print("Files organized successfully.")
    else:
        print("Directory not found or invalid.")
